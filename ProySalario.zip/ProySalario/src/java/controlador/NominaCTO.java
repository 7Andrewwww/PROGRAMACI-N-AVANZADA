/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import modelo.Empleado;
import modelo.Nomina;

@WebServlet("/NominaCTO")
public class NominaCTO extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Recibir parámetros del formulario
            String id = request.getParameter("id");
            String nombre = request.getParameter("nombre");
            
            // Verificar si los parámetros están vacíos o nulos
            if(id == null || nombre == null || request.getParameter("salarioBasico") == null || request.getParameter("diasTrabajados") == null) {
                throw new IllegalArgumentException("Uno o más campos están vacíos");
            }

            // Conversión de parámetros
            double salarioBasico = Double.parseDouble(request.getParameter("salarioBasico"));
            int diasTrabajados = Integer.parseInt(request.getParameter("diasTrabajados"));

            // Crear empleado y calcular nómina
            Empleado empleado = new Empleado(id, nombre, salarioBasico, diasTrabajados);
            Nomina nomina = new Nomina(empleado);

            // Enviar datos a la vista
            request.setAttribute("empleado", empleado);
            request.setAttribute("nomina", nomina);

            // Redireccionar a la página JSP
            request.getRequestDispatcher("nomina.jsp").forward(request, response);
        } catch (NumberFormatException e) {
            // Manejo de excepciones de formato numérico
            response.getWriter().println("Error: Formato inválido en los datos numéricos.");
        } catch (IllegalArgumentException e) {
            // Manejo de campos vacíos o nulos
            response.getWriter().println("Error: " + e.getMessage());
        } catch (Exception e) {
            // Manejo de errores generales
            e.printStackTrace();
            response.getWriter().println("Error: Ocurrió un problema inesperado.");
        }
    }
}
