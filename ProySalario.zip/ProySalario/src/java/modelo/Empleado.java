/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class Empleado extends Persona {
    private double salarioBasico;
    private int diasTrabajados;

    // Constructor
    public Empleado(String id, String nombre, double salarioBasico, int diasTrabajados) {
        super(id, nombre);
        this.salarioBasico = salarioBasico;
        this.diasTrabajados = diasTrabajados;
    }

    // Getters and Setters
    public double getSalarioBasico() {
        return salarioBasico;
    }

    public void setSalarioBasico(double salarioBasico) {
        this.salarioBasico = salarioBasico;
    }

    public int getDiasTrabajados() {
        return diasTrabajados;
    }

    public void setDiasTrabajados(int diasTrabajados) {
        this.diasTrabajados = diasTrabajados;
    }

    // Método para calcular el salario total basado en los días trabajados
    public double calcularSalario() {
        return (salarioBasico / 30) * diasTrabajados;
    }
}

