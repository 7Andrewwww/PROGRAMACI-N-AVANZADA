/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class Nomina {
    private static final double DESCUENTO_SALUD = 0.04;
    private static final double DESCUENTO_PENSION = 0.04;
    private static final double AUXILIO_TRANSPORTE = 140606; // Valor fijo en pesos colombianos

    private Empleado empleado;

    // Constructor
    public Nomina(Empleado empleado) {
        this.empleado = empleado;
    }

    // Calcular el descuento de salud
    public double getDescuentoSalud() {
        return empleado.calcularSalario() * DESCUENTO_SALUD;
    }

    // Calcular el descuento de pensión
    public double getDescuentoPension() {
        return empleado.calcularSalario() * DESCUENTO_PENSION;
    }

    // Calcular el auxilio de transporte (si aplica)
    public double getAuxilioTransporte() {
        if (empleado.getSalarioBasico() <= 2 * 1160000) { // Si el salario básico es menor o igual a 2 SMMLV
            return AUXILIO_TRANSPORTE;
        }
        return 0;
    }

    // Calcular el salario neto a pagar
    public double calcularSalarioNeto() {
        double salarioBase = empleado.calcularSalario();
        return salarioBase - getDescuentoSalud() - getDescuentoPension() + getAuxilioTransporte();
    }
}

