    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import negocio.Producto;
import negocio.guardaProducto;

@WebServlet(name = "registraProducto", urlPatterns = {"/registraProducto"})
public class registraProducto extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            int clave = Integer.parseInt(request.getParameter("clave"));
            String nombre = request.getParameter("nombre");
            Double precio = Double.parseDouble(request.getParameter("precio"));
            int cantidad = Integer.parseInt(request.getParameter("cant"));

            Producto producto = new Producto(clave, nombre, precio, cantidad);

            ServletContext sc = this.getServletContext();
            String path = sc.getRealPath("/WEB-INF/Productos.txt");
            path = path.replace('\\', '/');

            // Guardar en archivo
            guardaProducto.add(producto, path);
            request.setAttribute("atribProd", producto);
            request.getRequestDispatcher("/muestraRegistro.jsp").forward(request, response);
        } catch (Exception e) {
            // Manejo de errores
            out.println("<html><body><h1>Error: " + e.getMessage() + "</h1></body></html>");
        } finally {
            out.close();
        }
    }
}
