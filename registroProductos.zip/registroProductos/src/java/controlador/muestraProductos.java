/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author A n d r e s
 */
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import negocio.Producto;
import negocio.leeProductos;

@WebServlet(name = "muestraProductos", urlPatterns = {"/muestraProductos"})
public class muestraProductos extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        ArrayList<Producto> productos = new ArrayList<>();
        try {
            ServletContext sc = this.getServletContext();
            String path = sc.getRealPath("/WEB-INF/Productos.txt");
            path = path.replace('\\', '/');

            // Limpiar el contador antes de leer productos
            leeProductos.clearCont();
            productos = leeProductos.leeProductos(path);
            int cont = leeProductos.getCont();

            // Configurar atributos para la vista
            request.setAttribute("Productos", productos);
            request.setAttribute("contador", String.valueOf(cont));

            // Redirigir a la página de despliegue
            request.getRequestDispatcher("/despliegaProductos.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace(); // Para depuración
            request.setAttribute("errorMessage", "Ocurrió un error al cargar los productos.");
            request.getRequestDispatcher("/error.jsp").forward(request, response); // Redirigir a una página de error
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
