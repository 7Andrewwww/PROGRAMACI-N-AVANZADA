/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocio;

/**
 *
 * @author A n d r e s
 */
public class Producto {
 private int clave;
 private String nombre;
 private Double precio;
 private int cantidad;
 
 public Producto(int clave, String nombre,
 Double precio,int cant){
 this.clave = clave;
 this.nombre = nombre;
 this.precio = precio;
 this.cantidad = cant;
 }
 
 public int getClave(){
 return clave;
 }
 
 public String getNombre(){
 return nombre;
 }
 
 public Double getPrecio(){
 return precio;
 }
 
 public int getCantidad(){
 return cantidad;
 }
}

